# Install latest OpenAI Codex CLI (Linux x86_64) to ~/xbin and add a hardlink 'facLLA2'

set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$script_dir"

# Download the latest Linux x86_64 (musl) build from the GitHub "latest" release
# (musl build is broadly compatible across distros)
tmpdir="$(mktemp -d)"
curl -fL -o "$tmpdir/codex.tar.gz" \
  https://github.com/openai/codex/releases/latest/download/codex-x86_64-unknown-linux-musl.tar.gz

# Unpack and install
tar -xzf "$tmpdir/codex.tar.gz" -C "$tmpdir"
# Archive contains a single binary like: codex-x86_64-unknown-linux-musl
install -m 0755 "$tmpdir"/codex-x86_64-unknown-linux-musl "$script_dir/codex"

# Create a hardlink named facLLA2 (falls back to a copy if hardlink isn't possible)
ln -f "$script_dir/codex" "$script_dir/facLLA2" || cp -a "$script_dir/codex" "$script_dir/facLLA2"
rm -f "$script_dir/codex"

# Cleanup
rm -rf "$tmpdir"

# Optional: add ~/xbin to PATH for new shells (if not already there)
case ":$PATH:" in (*":$script_dir:"*) ;; (*) echo "export PATH=\"$script_dir:\$PATH\"" >> "$HOME/.bashrc";; esac

# Quick sanity check
"$script_dir/facLLA2" --version 2>/dev/null || "$script_dir/facLLA2" help || true
