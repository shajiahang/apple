# Files to copy for the Virtual KO + age prediction pipeline (minimal)

This list is based on the current scripts in `virtual_knockout_cell2sentence` and their hardcoded/default paths. Copy only the items below to a new Linux machine.

## Required for Step 1: Virtual KO generation
- `virtual_knockout_multigene.py` — main KO generator.
- `beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv` — input matrix currently hardcoded in `virtual_knockout_multigene.py` (size ~142M).

## Optional: other input matrices (only if you change the script to use them)
- `beta_nonzero_sc_log.csv` — full matrix (size ~859M).
- `beta_nonzero_sc_log.subsampled_200perdonor_seed0.csv` — alternative subsample (size ~180M).

## Required for Step 2: Age prediction (full pipeline)
- `predict_gene_ko_age.py` — predicts KO ages and plots.
- `/home/jiahang/kellie_code/data/beta_output/models/elastic_net_cv_reg_single_beta.pkl` — pretrained ElasticNet model (size ~443K).
- `/home/jiahang/kellie_code/data/beta_outputpredictions/csvs/preds_df_single_elastic_net_beta.csv` — baseline/reference predictions (size ~1.6M).
- `beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv` — control matrix for donor‑level plots; must match the KO input matrix.

## Optional: avoid re-downloading the 27B model from Hugging Face
- `/local/jiahang/hf_cache` — Hugging Face cache used by `virtual_knockout_multigene.py` (very large; only copy if you want to skip downloading `vandijklab/C2S-Scale-Gemma-2-27B`).

## Not needed: existing KO outputs/predictions (per your request)
- `/local/jiahang/in_silico_perturb_1019/cell2sentence/beta_nonzero_sc_log_*_KO*.csv`
- `/local/jiahang/in_silico_perturb_1019/cell2sentence/beta_nonzero_sc_log_*_KO*.csv.ckpt.json`
- `/local/jiahang/in_silico_perturb_1019/cell2sentence/predicted_age_*.csv`
- `/local/jiahang/in_silico_perturb_1019/cell2sentence/*.png`

## Optional: only if you need to rebuild `beta_nonzero_sc_log*.csv` from raw counts
- `build_beta_nonzero_sc_log.py` — preprocessing helper.
- `/home/jiahang/cornell/scRNA-seq-aging-clock/counts matrices for each cell type-selected/beta_counts_matrix.csv` — raw counts (size ~1.6G).
- `/home/jiahang/kellie_code/data/beta_output/important_genes/nonzero_elastic_net_beta.csv` — nonzero gene list (size ~87K).
- `/home/jiahang/kellie_code/scRNA-seq-aging-clock/preprocessing/` — contains `utils.py` used by `build_beta_nonzero_sc_log.py`.

## Not needed (do not copy)
- `log_shard_*.txt`
- `__pycache__/`
- `tff3_virtual_knockout_notebook.py` — superseded by `virtual_knockout_multigene.py`.
- `virtual_knockout_pipeline.py` — separate preprocessing script, not used in the KO pipeline above.
- `README_run_tff3.md` — documentation only.

## Post‑migration checklist (paths + environment)
- If the new machine uses different directories, update paths or pass CLI flags instead of editing code:
- `virtual_knockout_multigene.py`
- `input_path` (currently `beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv` in this repo)
- `output_dir` (currently `/local/jiahang/in_silico_perturb_1019/cell2sentence`)
- `HF_HOME` (defaults to `/local/jiahang/hf_cache`; point to the copied cache)
- `predict_gene_ko_age.py`
- `--data_dir` (defaults to `/local/jiahang/in_silico_perturb_1019/cell2sentence`)
- `--model_path` (defaults to `/home/jiahang/kellie_code/data/beta_output/models/elastic_net_cv_reg_single_beta.pkl`)
- `--reference_csv` (defaults to `/home/jiahang/kellie_code/data/beta_outputpredictions/csvs/preds_df_single_elastic_net_beta.csv`)
- `--control_csv` (defaults to `beta_nonzero_sc_log.csv` in this repo; set it to the same input matrix you used for KO)
- Ensure the output directory exists and is writable.
- If running offline, set `HF_HOME` to the copied cache and consider `TRANSFORMERS_OFFLINE=1`.
- Python deps you’ll need: `torch`, `transformers`, `pandas`, `numpy`, `scikit-learn`, `seaborn`, `matplotlib`, `loguru`.
