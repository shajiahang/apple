# c2sKO (local run)

## Layout
- `scripts/` Python entry points
- `data/` input matrices
- `models/` pretrained model artifacts
- `reference/` baseline predictions
- `hf_cache/` HuggingFace cache
- Output directory: `/texera/amber/c2sKO_output`

## Quick start
All commands assume the `c2sKO` conda env.

1) Virtual knockout (Cell2Sentence)
```bash
conda run -n c2sKO python scripts/virtual_knockout_multigene.py \
  --target_genes TUBB4B \
  --batch_size 32
```
Outputs:
- `/texera/amber/c2sKO_output/beta_nonzero_sc_log_TUBB4B_KO.csv`
- Checkpoint: same name + `.ckpt.json`

2) Predict KO ages (ElasticNet)
```bash
conda run -n c2sKO python scripts/predict_gene_ko_age.py TUBB4B
```
Outputs:
- `/texera/amber/c2sKO_output/predicted_age_TUBB4B.csv`
- Donor plots under `/texera/amber/c2sKO_output` (unless `--no_plots`)

## Tuning GPU utilization
- Increase `--batch_size` until GPU utilization is near full and memory is stable.
- For multi-GPU, pass `--gpu_ids "0,1"` and launch multiple shards with `--shard_idx/--num_shards`.
- HF cache is set to `hf_cache/` under the repo.

## Inputs used by default
- KO input matrix: `data/beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv`
- Model: `models/elastic_net_cv_reg_single_beta.pkl`
- Reference predictions: `reference/preds_df_single_elastic_net_beta.csv`
