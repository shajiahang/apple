#!/usr/bin/env python3
"""
Predict cell ages for a virtual knockout gene using a pre-trained ElasticNet model.

Workflow:
1) Find all KO matrices for the given gene in /local/.../cell2sentence.
2) If sharded (part0/part1/...), row-stack into one cells×genes matrix.
3) Load the pre-trained model (do not modify weights).
4) Align features to the model by zero-padding missing columns.
5) Predict KO ages and merge with baseline predictions from
   DEFAULT_REFERENCE_PRED_PATH, renaming columns to:
   - ReferencePredictedAge (pre‑KO)
   - KOPredictedAge (post‑KO)
   TrueAge/other reference columns are preserved.
6) (Unless --no_plots) pseudobulk by patient and save donor‑level
   expression comparison plots: heatmap, PCA trajectory, slope chart.
"""

import argparse
import json
import pickle
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_DIR = Path("/texera/amber/c2sKO_output")
DEFAULT_MODEL_PATH = REPO_ROOT / "models" / "elastic_net_cv_reg_single_beta.pkl"
DEFAULT_OUTPUT_DIR = DEFAULT_DATA_DIR
DEFAULT_REFERENCE_PRED_PATH = (
    REPO_ROOT / "reference" / "preds_df_single_elastic_net_beta.csv"
)
DEFAULT_CONTROL_CSV = REPO_ROOT / "data" / "beta_nonzero_sc_log.csv"
CONTROL_CANDIDATE_PATHS = [
    REPO_ROOT / "data" / "beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv",
    REPO_ROOT / "data" / "beta_nonzero_sc_log.subsampled_200perdonor_seed0.csv",
]


def list_available_genes(data_dir: Path) -> List[str]:
    """
    Scan data_dir for KO matrices and return unique gene symbols.
    Matches files like:
      beta_nonzero_sc_log_<GENE>_KO.csv
      beta_nonzero_sc_log_<GENE>_KO_partN.csv
    """
    ko_re = re.compile(
        r"beta_nonzero_sc_log_(.+?)_KO(?:_part\d+)?\.csv$",
        flags=re.IGNORECASE,
    )
    genes = {}
    for p in data_dir.glob("beta_nonzero_sc_log_*_KO*.csv"):
        m = ko_re.match(p.name)
        if not m:
            continue
        g = m.group(1)
        genes[g.upper()] = g  # preserve original casing from first hit
    return [genes[k] for k in sorted(genes)]


def output_csv_for_gene(
    gene: str, args: argparse.Namespace, output_dir: Path, is_batch: bool
) -> Path:
    """
    Determine output CSV path for a gene.
    In batch mode, always use default predicted_age_<GENE>.csv.
    """
    if is_batch or not args.output_csv:
        return output_dir / f"predicted_age_{gene}.csv"
    out_path = Path(args.output_csv)
    return output_dir / (out_path.name if out_path.is_absolute() else out_path)


def load_reference_predictions(ref_path: Path) -> pd.DataFrame:
    """
    Load baseline (pre‑KO) predictions and normalize column names.
    Returns a DataFrame indexed by cell name with ReferencePredictedAge present.
    """
    ref_df = pd.read_csv(ref_path, index_col=0, low_memory=False)

    pred_col = None
    for c in ref_df.columns:
        if c.lower() in {"predicted_age", "predictedage", "predicted"}:
            pred_col = c
            break
    if pred_col is None:
        raise ValueError(
            f"Could not find predicted age column in reference CSV {ref_path}. "
            f"Columns: {list(ref_df.columns)}"
        )
    ref_df = ref_df.rename(columns={pred_col: "ReferencePredictedAge"})

    abs_col = None
    for c in ref_df.columns:
        if c.lower() in {"abs_err", "absoluteerror", "absolute_error", "abserr"}:
            abs_col = c
            break
    if abs_col is not None:
        ref_df = ref_df.rename(columns={abs_col: "ReferenceAbsoluteError"})

    return ref_df


def find_gene_files(gene: str, data_dir: Path) -> List[Path]:
    """
    Locate KO CSVs for a gene.
    Expected naming from virtual_knockout_multigene.py:
      beta_nonzero_sc_log_<GENE>_KO.csv
      beta_nonzero_sc_log_<GENE>_KO_part<idx>.csv
    """
    gene = gene.strip()
    if not gene:
        raise ValueError("Gene name is empty.")

    pattern = f"beta_nonzero_sc_log_{gene}_KO*.csv"
    files = list(data_dir.glob(pattern))

    if not files:
        # Case-insensitive fallback
        ci_matches = []
        for p in data_dir.glob("beta_nonzero_sc_log_*_KO*.csv"):
            if re.search(
                rf"beta_nonzero_sc_log_{re.escape(gene)}_KO",
                p.name,
                flags=re.IGNORECASE,
            ):
                ci_matches.append(p)
        files = ci_matches

    if not files:
        raise FileNotFoundError(
            f"No files found for gene '{gene}' in {data_dir}. "
            f"Looked for pattern '{pattern}'."
        )

    def sort_key(p: Path) -> Tuple[int, str]:
        m = re.search(r"_part(\d+)", p.stem)
        part = int(m.group(1)) if m else -1
        return part, p.name

    files.sort(key=sort_key)
    return files


def shard_index_from_filename(path: Path) -> int:
    """
    Return the shard index encoded in a KO CSV filename.
    Non-sharded files are treated as shard 0.
    """
    m = re.search(r"_part(\d+)", path.stem)
    return int(m.group(1)) if m else 0


def validate_shards_completed(
    gene: str, files: List[Path]
) -> Tuple[bool, Optional[str]]:
    """
    If checkpoint files (*.csv.ckpt.json) exist for this gene, ensure all shards
    are present and marked completed. Returns (ok, reason_if_not_ok).
    Genes without checkpoints are treated as ready.
    """
    ckpt_info = {}
    num_shards_val: Optional[int] = None
    found_ckpt = False

    for csv_path in files:
        ckpt_path = csv_path.with_suffix(csv_path.suffix + ".ckpt.json")
        if not ckpt_path.exists():
            continue
        found_ckpt = True
        try:
            with open(ckpt_path, "r") as fh:
                payload = json.load(fh)
        except Exception as e:
            return False, f"could not read checkpoint {ckpt_path}: {e}"

        shard_idx = payload.get("shard_idx")
        shard_total = payload.get("num_shards")
        if shard_idx is None or shard_total is None:
            return False, f"checkpoint {ckpt_path} missing shard_idx/num_shards"

        shard_idx = int(shard_idx)
        shard_total = int(shard_total)
        if shard_idx < 0:
            return False, f"checkpoint {ckpt_path} has invalid shard_idx {shard_idx}"

        if num_shards_val is None:
            num_shards_val = shard_total
        elif shard_total != num_shards_val:
            return (
                False,
                f"inconsistent num_shards across checkpoints ({num_shards_val} vs {shard_total})",
            )

        ckpt_info[shard_idx] = {
            "completed": bool(payload.get("completed", False)),
            "path": ckpt_path,
        }

    if not found_ckpt:
        return True, None

    if num_shards_val is None:
        return False, "checkpoint present but num_shards missing"

    expected = set(range(num_shards_val))
    csv_by_idx = {shard_index_from_filename(f): f for f in files}
    missing_csv = sorted(expected - set(csv_by_idx))
    missing_ckpt = sorted(expected - set(ckpt_info))
    incomplete = sorted([idx for idx, meta in ckpt_info.items() if not meta["completed"]])

    problems = []
    if missing_csv:
        problems.append(f"missing CSV shard(s) {missing_csv}")
    if missing_ckpt:
        problems.append(f"missing checkpoint(s) {missing_ckpt}")
    if incomplete:
        problems.append(f"incomplete shard(s) {incomplete}")
    if problems:
        return False, "; ".join(problems)

    extra_csv = sorted(set(csv_by_idx) - expected)
    extra_ckpt = sorted(set(ckpt_info) - expected)
    if extra_csv:
        problems.append(f"unexpected CSV shard index(es) {extra_csv}")
    if extra_ckpt:
        problems.append(f"unexpected checkpoint shard index(es) {extra_ckpt}")
    if problems:
        return False, "; ".join(problems)

    return True, None


def load_control_matrix(path: Path, cache: Dict[Path, Optional[pd.DataFrame]]) -> Optional[pd.DataFrame]:
    """
    Load and cache a control expression matrix. Returns None if load fails.
    """
    if path in cache:
        return cache[path]
    if not path.exists():
        cache[path] = None
        return None
    try:
        cache[path] = pd.read_csv(path, index_col=0, low_memory=False).fillna(0.0)
    except Exception as e:
        print(f"Could not load control matrix {path}: {e}")
        cache[path] = None
    return cache[path]


def select_control_matrix(
    ko_index: pd.Index,
    control_cache: Dict[Path, Optional[pd.DataFrame]],
    fallback_path: Path,
) -> Tuple[Optional[pd.DataFrame], Optional[Path], str]:
    """
    Choose a control expression matrix whose rows match the KO matrix.
    Preference order:
      1) CONTROL_CANDIDATE_PATHS with exact index match,
      2) CONTROL_CANDIDATE_PATHS where KO index is a subset,
      3) fallback control path (exact or subset),
      4) first successfully loaded control (even if mismatched), otherwise None.
    Returns (control_df or None, path or None, match_reason).
    """
    candidates: List[Path] = []
    candidates.extend(CONTROL_CANDIDATE_PATHS)
    if fallback_path not in candidates:
        candidates.append(fallback_path)

    # Exact index match
    for path in candidates:
        df = load_control_matrix(path, control_cache)
        if df is None:
            continue
        if df.index.equals(ko_index):
            return df, path, "exact_index"

    # KO index subset of control
    ko_set = set(ko_index)
    for path in candidates:
        df = load_control_matrix(path, control_cache)
        if df is None:
            continue
        if ko_set.issubset(set(df.index)):
            return df.loc[ko_index], path, "subset_index"

    # Any loaded control as a last resort
    for path in candidates:
        df = control_cache.get(path)
        if df is not None:
            return df, path, "fallback_any"

    return None, None, "none_available"


def load_and_stack(files: List[Path]) -> pd.DataFrame:
    """
    Load one or more KO CSVs and row-stack into a single DataFrame.
    """
    dfs: List[pd.DataFrame] = []
    base_cols: Optional[pd.Index] = None

    for f in files:
        df = pd.read_csv(f, index_col=0, low_memory=False)
        if base_cols is None:
            base_cols = df.columns
        else:
            if not df.columns.equals(base_cols):
                # Align to base columns if any mismatch
                df = df.reindex(columns=base_cols, fill_value=0.0)
        dfs.append(df)

    stacked = pd.concat(dfs, axis=0)
    stacked = stacked.fillna(0.0)
    return stacked


def load_ko_matrix_on_the_fly(
    files: List[Path],
) -> Tuple[pd.DataFrame, List[Path]]:
    """
    Load KO matrix for a gene. If multiple part files are present, row-stack them
    on the fly (no combined file is written).
    Returns the matrix and the list of files used.
    """
    shard_re = re.compile(r"_part\d+$")
    shard_files = [f for f in files if shard_re.search(f.stem)]
    used = shard_files if shard_files else files

    if len(used) > 1:
        print(f"Stacking {len(used)} file(s) on the fly.")
    X = load_and_stack(used)
    return X, used


def align_to_model(
    X: pd.DataFrame, model, fill_value: float = 0.0
) -> Tuple[pd.DataFrame, Optional[np.ndarray]]:
    """
    Align input columns to model features.
    If model exposes feature_names_in_, reindex to those features (zero-fill missing).
    Otherwise, fall back to using X as-is only if feature count matches.
    """
    features = getattr(model, "feature_names_in_", None)
    if features is not None:
        features = np.array(features, dtype=str)
        X_aligned = X.reindex(columns=features, fill_value=fill_value)
        missing = pd.Index(features).difference(X.columns)
        if len(missing) > 0:
            print(f"Aligned to {len(features)} model features; "
                  f"{len(missing)} missing features were zero-filled.")
        else:
            print(f"Aligned to {len(features)} model features; no missing features.")
        return X_aligned, features

    n_expected = getattr(model, "n_features_in_", None)
    if n_expected is not None and n_expected == X.shape[1]:
        print(
            "Model has no feature_names_in_; using input features in current order."
        )
        return X, None

    raise ValueError(
        "Model does not expose feature_names_in_, and feature count does not match "
        "input. Cannot safely align features."
    )


def pseudobulk_by_patient(df: pd.DataFrame) -> pd.DataFrame:
    """
    Average expression across all cells for each patient (donor).
    Patient ID is the first 8 characters of each row name.
    Returns patients × genes DataFrame.
    """
    patient_ids = pd.Index(df.index.astype(str)).str[:8]
    pb = df.groupby(patient_ids).mean()
    pb.index.name = "patient_id"
    return pb


def make_donor_level_plots(
    gene: str,
    ko_df: pd.DataFrame,
    control_path: Path,
    output_dir: Path,
    top_n_genes: int = 50,
    slope_gene: Optional[str] = None,
    control_df: Optional[pd.DataFrame] = None,
) -> None:
    """
    Create donor-level comparison plots between control and KO datasets:
      A) Heatmap of top log-fold-change genes across donors.
      B) Paired PCA trajectory (Control → KO arrows).
      C) Paired slope chart for a specific gene.
    All plots are saved under output_dir.
    """
    if control_df is None:
        print(f"Loading control matrix from {control_path} ...")
        control_df_local = pd.read_csv(
            control_path, index_col=0, low_memory=False
        ).fillna(0.0)
    else:
        control_df_local = control_df

    # Align genes to KO columns for fair comparison
    if not control_df_local.columns.equals(ko_df.columns):
        control_df_local = control_df_local.reindex(
            columns=ko_df.columns, fill_value=0.0
        )

    pb_control = pseudobulk_by_patient(control_df_local)
    pb_ko = pseudobulk_by_patient(ko_df)

    patients = pb_control.index.intersection(pb_ko.index)
    if len(patients) == 0:
        raise ValueError("No overlapping patients between control and KO datasets.")
    if len(patients) != len(pb_control.index) or len(patients) != len(pb_ko.index):
        print(
            f"Warning: patient sets differ (control={len(pb_control)}, KO={len(pb_ko)}). "
            f"Using intersection (n={len(patients)})."
        )
    pb_control = pb_control.loc[patients]
    pb_ko = pb_ko.loc[patients]

    delta = pb_ko - pb_control  # log-expression difference ≈ log2 fold change
    gene_scores = delta.abs().mean(axis=0).drop(gene, errors="ignore")
    top_gene_scores = gene_scores.sort_values(ascending=False).head(top_n_genes)
    top_genes = top_gene_scores.index.tolist()

    # Order patients by overall magnitude of change across top genes (largest shifts first)
    patient_scores = delta[top_genes].abs().mean(axis=1).sort_values(ascending=False)
    patients_ordered = patient_scores.index.tolist()

    # Consistent donor colors across plots
    palette = sns.color_palette("husl", len(patients_ordered))
    donor_color = dict(zip(patients_ordered, palette))

    # A) Heatmap
    heatmap_path = output_dir / f"donor_log2fc_heatmap_{gene}.png"
    hm_data = delta.loc[patients_ordered, top_genes].T  # genes × patients
    # Add signed mean change to row labels for interpretability
    mean_delta = delta[top_genes].mean(axis=0).loc[top_genes]
    hm_data.index = [f"{g} ({mean_delta[g]:+.2f})" for g in top_genes]

    plt.figure(figsize=(0.35 * len(patients_ordered) + 4, 0.25 * len(top_genes) + 4))
    sns.heatmap(
        hm_data,
        cmap="coolwarm",
        center=0.0,
        cbar_kws={"label": "KO − Control (log‑fold change)"},
    )
    plt.title(
        f"Top {len(top_genes)} donor‑level changes after {gene} KO\n"
        "Rows sorted by mean |Δ| and columns sorted by donor shift"
    )
    plt.xlabel("Patient (ordered by overall KO effect)")
    plt.ylabel("Gene (label shows mean KO−Control)")
    plt.tight_layout()
    plt.savefig(heatmap_path, dpi=300)
    plt.close()
    print(f"Saved heatmap to {heatmap_path}")

    # B) Paired PCA trajectory
    pca_path = output_dir / f"donor_pca_trajectory_{gene}.png"
    combined = pd.concat([pb_control, pb_ko], axis=0)
    conditions = (["Control"] * len(patients_ordered)) + (["KO"] * len(patients_ordered))
    patient_labels = list(patients_ordered) + list(patients_ordered)

    scaler = StandardScaler(with_mean=True, with_std=False)
    X_scaled = scaler.fit_transform(combined.to_numpy())
    pcs = PCA(n_components=2).fit_transform(X_scaled)

    plot_df = pd.DataFrame(
        {"PC1": pcs[:, 0], "PC2": pcs[:, 1], "patient_id": patient_labels, "condition": conditions}
    )

    fig, ax = plt.subplots(figsize=(7, 6))

    for cond, marker in [("Control", "o"), ("KO", "^")]:
        sub = plot_df[plot_df["condition"] == cond]
        ax.scatter(
            sub["PC1"],
            sub["PC2"],
            c=[donor_color[p] for p in sub["patient_id"]],
            marker=marker,
            s=45,
            alpha=0.9,
            label=cond,
            edgecolors="none",
        )

    for pid in patients_ordered:
        c_row = plot_df[(plot_df["patient_id"] == pid) & (plot_df["condition"] == "Control")].iloc[0]
        k_row = plot_df[(plot_df["patient_id"] == pid) & (plot_df["condition"] == "KO")].iloc[0]
        ax.annotate(
            "",
            xy=(k_row.PC1, k_row.PC2),
            xytext=(c_row.PC1, c_row.PC2),
            arrowprops=dict(arrowstyle="->", color="gray", alpha=0.6, lw=1),
        )

    ax.set_title(f"PCA trajectory per donor (Control → {gene} KO)")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.legend(frameon=False)
    fig.subplots_adjust(bottom=0.22)
    fig.text(
        0.5,
        0.02,
        "Each color = donor (patient ID). Circles=Control, triangles=KO. "
        "Arrows show Control→KO shift in PCA of pseudobulk expression.",
        ha="center",
        fontsize=8,
    )
    fig.tight_layout(rect=[0, 0.08, 1, 1])
    plt.savefig(pca_path, dpi=300)
    plt.close(fig)
    print(f"Saved PCA trajectory plot to {pca_path}")

    # C) Paired slope chart for a gene of interest
    if slope_gene is None:
        slope_gene = top_genes[0] if top_genes else None
    if slope_gene is None:
        print("No genes available for slope chart; skipping.")
        return
    if slope_gene not in pb_control.columns:
        raise ValueError(f"slope_gene '{slope_gene}' not found in data columns.")

    slope_path = output_dir / f"donor_slope_{gene}_{slope_gene}.png"
    vals_control = pb_control[slope_gene]
    vals_ko = pb_ko[slope_gene]
    order = vals_control.sort_values().index

    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for pid in order:
        ax.plot(
            [0, 1],
            [vals_control.loc[pid], vals_ko.loc[pid]],
            marker="o",
            color=donor_color.get(pid, "gray"),
            alpha=0.9,
            lw=1,
        )
        # Label donors on the KO side for readability
        ax.text(
            1.03,
            vals_ko.loc[pid],
            pid,
            fontsize=6,
            va="center",
            ha="left",
            color=donor_color.get(pid, "gray"),
        )

    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Control", f"{gene} KO"])
    ax.set_ylabel("Pseudobulk expression")
    ax.set_title(f"Donor‑level change for {slope_gene} after {gene} KO\n(each line = one donor)")
    ax.set_xlim(-0.1, 1.25)
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    plt.savefig(slope_path, dpi=300)
    plt.close(fig)
    print(f"Saved slope chart to {slope_path}")


def make_donor_age_violin_slope_plot(
    gene: str,
    pred_df: pd.DataFrame,
    output_dir: Path,
) -> None:
    """
    Donor-level age comparison plot using cell-level predictions:
      - For each donor, draw a violin of cell-level predicted ages for
        ReferencePredictedAge and KOPredictedAge.
      - True age is shown as a single point per donor (no violin).
      - Lines connect donor medians between Reference and KO.
    """
    patient_ids = pd.Index(pred_df.index.astype(str)).str[:8]

    true_col = None
    for c in pred_df.columns:
        if c.lower() in {"true_age", "trueage"}:
            true_col = c
            break
    if true_col is None:
        raise ValueError(
            "True age column not found in prediction table. "
            f"Columns: {list(pred_df.columns)}"
        )

    df_cells = pred_df.copy()
    df_cells["patient_id"] = patient_ids

    true_age_by_patient = (
        df_cells.groupby("patient_id")[true_col].first().astype(float)
    )
    patients_ordered = true_age_by_patient.sort_values().index.tolist()

    n_patients = len(patients_ordered)
    width = 0.9
    step = width / n_patients
    offsets = np.linspace(-width / 2 + step / 2, width / 2 - step / 2, n_patients)
    offset_map = dict(zip(patients_ordered, offsets))

    palette = sns.color_palette("husl", n_patients)
    donor_color = dict(zip(patients_ordered, palette))

    # Collect per-patient distributions
    ref_dists = []
    ko_dists = []
    ref_medians = {}
    ko_medians = {}
    for pid in patients_ordered:
        sub = df_cells[df_cells["patient_id"] == pid]
        ref_vals = sub["ReferencePredictedAge"].to_numpy()
        ko_vals = sub["KOPredictedAge"].to_numpy()
        ref_dists.append(ref_vals)
        ko_dists.append(ko_vals)
        ref_medians[pid] = np.median(ref_vals)
        ko_medians[pid] = np.median(ko_vals)

    x_true = 0
    x_ref = 1
    x_ko = 2

    fig, ax = plt.subplots(figsize=(12, 6))

    # Reference violins
    pos_ref = [x_ref + offset_map[pid] for pid in patients_ordered]
    vp_ref = ax.violinplot(
        ref_dists,
        positions=pos_ref,
        widths=step * 0.9,
        showmeans=False,
        showmedians=False,
        showextrema=False,
    )
    for pid, body in zip(patients_ordered, vp_ref["bodies"]):
        body.set_facecolor(donor_color[pid])
        body.set_alpha(0.35)
        body.set_edgecolor("none")

    # KO violins
    pos_ko = [x_ko + offset_map[pid] for pid in patients_ordered]
    vp_ko = ax.violinplot(
        ko_dists,
        positions=pos_ko,
        widths=step * 0.9,
        showmeans=False,
        showmedians=False,
        showextrema=False,
    )
    for pid, body in zip(patients_ordered, vp_ko["bodies"]):
        body.set_facecolor(donor_color[pid])
        body.set_alpha(0.35)
        body.set_edgecolor("none")

    # Median points and paired lines (Reference -> KO)
    deltas = {}
    for pid in patients_ordered:
        xr = x_ref + offset_map[pid]
        xk = x_ko + offset_map[pid]
        yr = ref_medians[pid]
        yk = ko_medians[pid]
        deltas[pid] = yk - yr
        ax.plot([xr, xk], [yr, yk], color="gray", alpha=0.4, lw=0.8)
        ax.scatter([xr, xk], [yr, yk], color="black", s=8, zorder=3)

    # True age points per donor
    for pid in patients_ordered:
        xt = x_true + offset_map[pid]
        yt = true_age_by_patient.loc[pid]
        ax.scatter(xt, yt, color=donor_color[pid], edgecolor="black", s=25, zorder=4)
        ax.text(
            xt,
            yt,
            pid,
            fontsize=6,
            ha="center",
            va="bottom",
            color=donor_color[pid],
        )

    ax.set_xticks([x_true, x_ref, x_ko])
    ax.set_xticklabels(["True Age", "Reference Predicted", "KO Predicted"])
    ax.set_xlim(-0.6, 2.6)
    ax.set_ylabel("Age")
    ax.set_title(
        f"Cell-level predicted age per donor before and after {gene} KO\n"
        "Each colored violin is one donor and lines connect donor medians"
    )
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    # Delta summary annotation (KO median minus Reference median)
    delta_series = pd.Series(deltas).loc[patients_ordered]
    min_pid = delta_series.idxmin()
    max_pid = delta_series.idxmax()
    mean_delta = float(delta_series.mean())
    var_delta = float(delta_series.var())
    summary_text = "\n".join(
        [
            "Median KO minus Reference per donor",
            f"Mean delta {mean_delta:+.2f}",
            f"Variance {var_delta:.2f}",
            f"Most negative {min_pid} {delta_series[min_pid]:+.2f}",
            f"Most positive {max_pid} {delta_series[max_pid]:+.2f}",
        ]
    )
    ax.text(
        0.02,
        0.98,
        summary_text,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        bbox=dict(boxstyle="round", facecolor="white", alpha=0.8, edgecolor="gray"),
    )

    # Fixed y-limits for readability across runs
    ax.set_ylim(-5, 75)
    fig.tight_layout()

    out_path = output_dir / f"donor_age_violin_slope_{gene}.png"
    fig.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"Saved cell-level donor age violin plot to {out_path}")


def make_donor_age_delta_bar_plot(
    gene: str,
    pred_df: pd.DataFrame,
    output_dir: Path,
) -> None:
    """
    Bar plot of donor-level age delta:
      delta = median(KO predicted age) - median(reference predicted age).
    Bars are sorted ascending so largest decrease (most negative) is leftmost.
    """
    patient_ids = pd.Index(pred_df.index.astype(str)).str[:8]
    df = pred_df.copy()
    df["patient_id"] = patient_ids

    med = df.groupby("patient_id")[["ReferencePredictedAge", "KOPredictedAge"]].median()
    med["DeltaAge"] = med["KOPredictedAge"] - med["ReferencePredictedAge"]
    med_sorted = med.sort_values("DeltaAge")

    fig, ax = plt.subplots(figsize=(max(6, 0.4 * len(med_sorted)), 4.5))
    colors = sns.color_palette("coolwarm", len(med_sorted))

    ax.bar(range(len(med_sorted)), med_sorted["DeltaAge"], color=colors, alpha=0.9)
    ax.axhline(0, color="black", lw=1, linestyle="--", alpha=0.6)

    ax.set_xticks(range(len(med_sorted)))
    ax.set_xticklabels(med_sorted.index, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Median KO − Reference predicted age")
    ax.set_title(
        f"Donor age shift after {gene} KO\n"
        "Negative = younger vs reference (sorted by delta)"
    )
    fig.tight_layout()

    out_path = output_dir / f"donor_age_delta_bar_{gene}.png"
    fig.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"Saved donor age delta bar plot to {out_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Predict ages for a virtual knockout gene from Cell2Sentence outputs."
    )
    parser.add_argument(
        "gene",
        type=str,
        help=(
            "Gene symbol to predict (matches beta_nonzero_sc_log_<GENE>_KO*.csv), "
            "or 'all' to process all unprocessed KO genes."
        ),
    )
    parser.add_argument(
        "--data_dir",
        type=str,
        default=str(DEFAULT_DATA_DIR),
        help=f"Directory containing KO matrices (default: {DEFAULT_DATA_DIR}).",
    )
    parser.add_argument(
        "--model_path",
        type=str,
        default=str(DEFAULT_MODEL_PATH),
        help=f"Path to pretrained ElasticNet model (default: {DEFAULT_MODEL_PATH}).",
    )
    parser.add_argument(
        "--output_csv",
        type=str,
        default=None,
        help=(
            "Output CSV name or path. The file will always be written under "
            f"{DEFAULT_OUTPUT_DIR} (default: predicted_age_<GENE>.csv)."
        ),
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help=(
            "Recompute predictions and plots even if predicted_age_<GENE>.csv already exists."
        ),
    )
    parser.add_argument(
        "--reference_csv",
        type=str,
        default=str(DEFAULT_REFERENCE_PRED_PATH),
        help=(
            "Baseline (pre‑KO) predictions CSV to compare against. "
            f"Default: {DEFAULT_REFERENCE_PRED_PATH}"
        ),
    )
    parser.add_argument(
        "--control_csv",
        type=str,
        default=str(DEFAULT_CONTROL_CSV),
        help=(
            "Original (pre‑KO) expression matrix for donor‑level plots. "
            f"Default: {DEFAULT_CONTROL_CSV}"
        ),
    )
    parser.add_argument(
        "--top_n_genes",
        type=int,
        default=50,
        help="Number of top changing genes to show in the heatmap (default: 50).",
    )
    parser.add_argument(
        "--slope_gene",
        type=str,
        default=None,
        help=(
            "Gene to use for the paired slope chart. "
            "If omitted, uses the top changing non‑target gene."
        ),
    )
    parser.add_argument(
        "--no_plots",
        action="store_true",
        help="Skip donor‑level expression comparison plots.",
    )
    return parser.parse_args()


def process_gene(
    gene: str,
    args: argparse.Namespace,
    data_dir: Path,
    model,
    ref_base_df: pd.DataFrame,
    output_dir: Path,
    is_batch: bool,
    control_cache: Optional[Dict[Path, Optional[pd.DataFrame]]] = None,
    fallback_control_path: Optional[Path] = None,
    prevalidated_files: Optional[List[Path]] = None,
) -> None:
    """
    Run KO prediction + optional plots for one gene.
    Skips if output exists and --overwrite is not set.
    """
    out_csv = output_csv_for_gene(gene, args, output_dir, is_batch)
    if out_csv.exists() and not args.overwrite:
        print(f"[{gene}] {out_csv} already exists, skipping")
        return

    files = (
        prevalidated_files
        if prevalidated_files is not None
        else find_gene_files(gene, data_dir)
    )
    ok, reason = validate_shards_completed(gene, files)
    if not ok:
        print(f"[{gene}] Skipping due to incomplete shards: {reason}")
        return

    print(f"[{gene}] Found {len(files)} file(s)")

    X, used_files = load_ko_matrix_on_the_fly(files)
    if len(used_files) > 1:
        print(f"[{gene}] Loaded and stacked {len(used_files)} shards")
    print(f"[{gene}] KO matrix shape: {X.shape}")

    control_df_used: Optional[pd.DataFrame] = None
    control_path_used: Optional[Path] = None
    # Re-select control matrix now that we have the KO index
    if control_cache is not None and fallback_control_path is not None:
        control_df_used, control_path_used, match_reason = select_control_matrix(
            ko_index=X.index,
            control_cache=control_cache,
            fallback_path=fallback_control_path,
        )
        if control_df_used is not None and control_path_used is not None:
            print(
                f"[{gene}] Using control matrix {control_path_used.name} ({match_reason}) "
                f"rows={len(control_df_used)}"
            )
        elif not args.no_plots:
            print(f"[{gene}] No control matrix available for plots; skipping plot generation.")

    X_aligned, features = align_to_model(X, model, fill_value=0.0)
    ko_preds = model.predict(
        X_aligned[features] if features is not None else X_aligned
    )

    missing_in_ref = set(X_aligned.index) - set(ref_base_df.index)
    if missing_in_ref:
        raise ValueError(
            f"[{gene}] Reference predictions missing {len(missing_in_ref)} KO cell(s); "
            "provide a matching --reference_csv."
        )
    if len(ref_base_df.index) != len(X_aligned.index):
        print(
            f"[{gene}] Reference predictions contain {len(ref_base_df)} cells; "
            f"subsetting to {len(X_aligned)} KO cells."
        )
    ref_df = ref_base_df.loc[X_aligned.index].copy()
    ref_df["KOPredictedAge"] = ko_preds

    ref_df.to_csv(out_csv)
    print(f"[{gene}] Saved predictions to {out_csv}")

    if not args.no_plots:
        if control_df_used is None:
            print(f"[{gene}] No control matrix available; skipping plot generation.")
            return
        make_donor_level_plots(
            gene=gene,
            ko_df=X,
            control_path=control_path_used if control_path_used is not None else Path(args.control_csv),
            output_dir=output_dir,
            top_n_genes=args.top_n_genes,
            slope_gene=args.slope_gene,
            control_df=control_df_used,
        )
        make_donor_age_violin_slope_plot(
            gene=gene,
            pred_df=ref_df,
            output_dir=output_dir,
        )
        make_donor_age_delta_bar_plot(
            gene=gene,
            pred_df=ref_df,
            output_dir=output_dir,
        )


def main() -> None:
    args = parse_args()
    data_dir = Path(args.data_dir)
    model_path = Path(args.model_path)

    output_dir = DEFAULT_OUTPUT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    is_batch = args.gene.strip().lower() == "all"
    if is_batch and args.output_csv:
        print("Batch mode detected: ignoring --output_csv")

    gene_files_map = {}
    if is_batch:
        available = list_available_genes(data_dir)
        if not available:
            print(f"No KO matrices found under {data_dir}")
            return
        genes_to_run = []
        for g in available:
            out_path = output_dir / f"predicted_age_{g}.csv"
            if out_path.exists() and not args.overwrite:
                continue
            try:
                files = find_gene_files(g, data_dir)
            except FileNotFoundError as e:
                print(f"[{g}] Skipping: {e}")
                continue
            ok, reason = validate_shards_completed(g, files)
            if not ok:
                print(f"[{g}] Skipping due to incomplete shards: {reason}")
                continue
            gene_files_map[g] = files
            genes_to_run.append(g)
        if not genes_to_run:
            print(
                "No genes with completed shards left to process. "
                "Use --overwrite to redo existing outputs."
            )
            return
        print(f"Processing {len(genes_to_run)} gene(s): {', '.join(genes_to_run)}")
    else:
        target_gene = args.gene.strip()
        out_path = output_csv_for_gene(
            target_gene, args, output_dir=output_dir, is_batch=False
        )
        if out_path.exists() and not args.overwrite:
            print(f"[{target_gene}] {out_path} already exists, skipping")
            return
        try:
            files = find_gene_files(target_gene, data_dir)
        except FileNotFoundError as e:
            print(f"[{target_gene}] {e}")
            return
        ok, reason = validate_shards_completed(target_gene, files)
        if not ok:
            print(f"[{target_gene}] Skipping due to incomplete shards: {reason}")
            return
        genes_to_run = [target_gene]
        gene_files_map[target_gene] = files

    with open(model_path, "rb") as f:
        model = pickle.load(f)
    print(f"Loaded model from {model_path}")

    ref_base_df = load_reference_predictions(Path(args.reference_csv))
    print(f"Loaded reference predictions from {args.reference_csv}")

    control_cache: Dict[Path, Optional[pd.DataFrame]] = {}
    fallback_control_path = Path(args.control_csv)
    # Optionally warm the cache for the fallback control if plots are enabled
    if not args.no_plots:
        load_control_matrix(fallback_control_path, control_cache)

    for g in genes_to_run:
        try:
            process_gene(
                gene=g,
                args=args,
                data_dir=data_dir,
                model=model,
                ref_base_df=ref_base_df,
                output_dir=output_dir,
                is_batch=is_batch,
                control_cache=control_cache,
                fallback_control_path=fallback_control_path,
                prevalidated_files=gene_files_map.get(g),
            )
        except Exception as e:
            print(f"[{g}] Failed: {e}")
            if not is_batch:
                raise


if __name__ == "__main__":
    main()
