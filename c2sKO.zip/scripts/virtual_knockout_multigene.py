# %% [markdown]
# # Virtual knockout of genes with Cell2Sentence (27B)
# 
# - Input: log-normalized beta matrix `beta_nonzero_sc_log.csv`.
# - Patient ID: first 8 chars of each cell name.
# - Model: `vandijklab/C2S-Scale-Gemma-2-27B`.
# - Output: perturbed single-cell matrix saved to `/local/jiahang/in_silico_perturb_1019/cell2sentence/beta_nonzero_sc_log_<GENE>_KO*.csv`.

# %%
import os
import sys
import argparse
import csv
import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# --- Argument parsing for sharded data-parallel runs ---
parser = argparse.ArgumentParser(description="Virtual knockout of genes using Cell2Sentence")
parser.add_argument("--shard_idx", type=int, default=0, help="Index of current data shard (0-based)")
parser.add_argument("--num_shards", type=int, default=1, help="Total number of shards")
parser.add_argument("--batch_size", type=int, default=32, help="Batch size per worker")
parser.add_argument("--gpu_ids", type=str, default=None, help="Comma-separated GPU ids to make visible (e.g., '0,1')")
parser.add_argument(
    "--resume",
    dest="resume",
    action="store_true",
    help="Resume from existing output/checkpoint if present (default).",
)
parser.add_argument(
    "--no_resume",
    dest="resume",
    action="store_false",
    help="Do not resume from existing output/checkpoint.",
)
parser.set_defaults(resume=True)
parser.add_argument(
    "--overwrite",
    action="store_true",
    help="Delete existing output CSV/checkpoint before running.",
)
parser.add_argument(
    "--checkpoint_every",
    type=int,
    default=1,
    help="Write checkpoint every N batches (default: 1).",
)
parser.add_argument(
    "--target_genes",
    nargs="+",
    default=["TFF3"],
    help="List of gene symbols to knockout (one output per gene)",
)

if "ipykernel" in sys.modules:
    args = parser.parse_args(args=[])  # default args when run in a notebook cell
else:
    args = parser.parse_args()

# Set visible devices if provided on CLI; otherwise rely on env from launcher
if args.gpu_ids:
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_ids

# Optional: change cache dir for HF downloads
repo_root = Path(__file__).resolve().parent.parent
os.environ.setdefault("HF_HOME", str(repo_root / "hf_cache"))

target_genes = [g.strip() for g in args.target_genes if g.strip()]
if not target_genes:
    raise ValueError("At least one target gene must be provided via --target_genes")

print("CUDA visible devices:", os.environ.get("CUDA_VISIBLE_DEVICES"))
print("Torch CUDA available:", torch.cuda.is_available())
print(f"Shard {args.shard_idx + 1}/{args.num_shards}, batch_size={args.batch_size}")

# %%
# Paths and parameters
# input_path = repo_root / "data" / "beta_nonzero_sc_log.csv"
input_path = repo_root / "data" / "beta_nonzero_sc_log.subsampled_150perdonor_seed0.csv"
output_dir = Path("/texera/amber/c2sKO_output")
output_dir.mkdir(parents=True, exist_ok=True)

model_name = "vandijklab/C2S-Scale-Gemma-2-27B"
top_k_genes = 300  # how many top genes to keep in each cell sentence
batch_size = args.batch_size
max_new_tokens = 1500  # tokens to generate per cell
print("Target genes:", target_genes)

print("Input matrix:", input_path)
print("Output directory:", output_dir)

# %%
# Load expression matrix (already log-normalized)
df = pd.read_csv(input_path, index_col=0)

# Shard the cells across workers if requested
all_cells = df.index.to_numpy()
if args.num_shards > 1:
    chunks = np.array_split(all_cells, args.num_shards)
    my_cells = chunks[args.shard_idx]
    df = df.loc[my_cells]
    print(f"Processing shard {args.shard_idx} with {len(df)} cells (of {len(all_cells)} total).")
else:
    print(f"Processing all {len(df)} cells (no sharding).")

cells = df.index.to_numpy()
genes = df.columns.to_numpy()
gene_set = set(genes.tolist())
print("Matrix shape:", df.shape)

# Derive patient ID from cell name (first 8 chars)
patients = pd.Index(cells).str[:8]

# %%
# Build cell sentences and per-cell rank-sorted expressions
data = df.to_numpy()
n_cells, n_genes = data.shape

top_k = min(top_k_genes, n_genes)
top_genes_per_cell = []
top_expr_per_cell = []

for i in range(n_cells):
    row = data[i]
    order = np.argsort(-row)  # descending
    top_idx = order[:top_k]
    top_genes = genes[top_idx]
    top_expr = row[top_idx]
    top_genes_per_cell.append(top_genes)
    top_expr_per_cell.append(top_expr)

cell_sentences = [" ".join(g_list) for g_list in top_genes_per_cell]
print("Built cell sentences with top_k =", top_k)

# %%
# Load tokenizer and model
tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side="left")
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    device_map="auto",
    torch_dtype=torch.bfloat16,
    trust_remote_code=True,
)
model.eval()
first_param_device = next(model.parameters()).device
print("Model loaded. First shard device:", first_param_device)

# %%
# Prompt helpers
def build_prompt(cell_sentence: str, target_gene: str) -> str:
    return (
        f"The following is a list of {top_k} gene names ordered by descending expression level in a Homo sapiens cell. "
        f"Cell sentence: {cell_sentence}. "
        f"Simulate a knockout (silencing) of gene {target_gene} and return a new ranked gene list of the same length. "
        f"Return only a space-separated list of gene symbols."
    )


def clean_generated(gen_text: str, prompt: str, target_gene: str) -> list:
    """Strip prompt, split genes, drop duplicates, enforce vocabulary, drop target gene."""
    stripped = gen_text.replace(prompt, "").replace("<|endoftext|>", "").strip()
    gene_list = []
    seen = set()
    for token in stripped.replace(",", " ").split():
        g = token.strip()
        if not g:
            continue
        if g == target_gene:
            continue  # enforce knockout
        if g in gene_set and g not in seen:
            gene_list.append(g)
            seen.add(g)
    return gene_list


def complete_gene_list(generated, fallback, target_gene: str):
    """Pad/truncate to top_k using fallback ordering; always exclude target gene."""
    out = []
    seen = set()
    for g in generated:
        if g == target_gene or g in seen:
            continue
        out.append(g)
        seen.add(g)
        if len(out) == top_k:
            return out
    for g in fallback:
        if g == target_gene or g in seen:
            continue
        out.append(g)
        seen.add(g)
        if len(out) == top_k:
            break
    return out[:top_k]


# %%
# Generation loop helpers
col_to_idx = {g: i for i, g in enumerate(genes)}


def output_path_for_gene(target_gene: str) -> Path:
    if args.num_shards > 1:
        return output_dir / f"beta_nonzero_sc_log_{target_gene}_KO_part{args.shard_idx}.csv"
    return output_dir / f"beta_nonzero_sc_log_{target_gene}_KO.csv"


def checkpoint_path_for_gene(target_gene: str) -> Path:
    output_path = output_path_for_gene(target_gene)
    return output_path.with_suffix(output_path.suffix + ".ckpt.json")


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _format_duration(seconds: float) -> str:
    if seconds is None:
        return "unknown"
    if not np.isfinite(seconds):
        return "unknown"
    seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    with open(tmp_path, "w") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(tmp_path, path)


def _load_json(path: Path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def _sha256_of_strings(values) -> str:
    import hashlib

    h = hashlib.sha256()
    for v in values:
        h.update(str(v).encode("utf-8"))
        h.update(b"\0")
    return h.hexdigest()


cells_sha256 = _sha256_of_strings(df.index)
genes_sha256 = _sha256_of_strings(df.columns)


def _read_last_non_empty_line(path: Path, chunk_size: int = 1024 * 1024, max_chunks: int = 128):
    """
    Returns the last non-empty line (as str) without reading the whole file.
    If the file has no non-empty lines, returns None.
    """
    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        file_size = f.tell()
        if file_size == 0:
            return None

        buffer = b""
        pos = file_size
        for _ in range(max_chunks):
            read_size = min(chunk_size, pos)
            pos -= read_size
            f.seek(pos)
            chunk = f.read(read_size)
            buffer = chunk + buffer
            if b"\n" in chunk or pos == 0:
                lines = buffer.splitlines()
                for line in reversed(lines):
                    if line.strip():
                        return line.decode("utf-8", errors="ignore")
        if buffer.strip():
            return buffer.decode("utf-8", errors="ignore")
        return None


def _infer_next_cell_idx_from_csv(output_path: Path, index: pd.Index):
    """
    Infer next cell index from the last completed row in an existing CSV.
    Returns:
      int: next cell idx (0..n_cells) if inferable,
      None: if file looks corrupted/unparseable.
    """
    if not output_path.exists():
        return 0

    last_line = _read_last_non_empty_line(output_path)
    if last_line is None:
        return 0

    try:
        first_field = next(csv.reader([last_line]))[0]
    except Exception:
        return None

    cell_id = (first_field or "").strip().strip('"')
    if not cell_id:
        return 0  # header-only

    if cell_id not in index:
        return None

    try:
        loc = index.get_loc(cell_id)
    except KeyError:
        return None
    if isinstance(loc, slice):
        loc = loc.stop - 1
    elif isinstance(loc, np.ndarray):
        loc = int(loc.max())
    return int(loc) + 1


def run_virtual_knockout(target_gene: str):
    output_path = output_path_for_gene(target_gene)
    ckpt_path = checkpoint_path_for_gene(target_gene)
    target_idx = col_to_idx.get(target_gene, None)
    if target_idx is None:
        print(
            f"Warning: target gene {target_gene} not found in matrix columns; will not zero a dedicated column."
        )

    if args.overwrite:
        if output_path.exists():
            output_path.unlink()
        if ckpt_path.exists():
            ckpt_path.unlink()

    ckpt = _load_json(ckpt_path) if args.resume else None
    if ckpt and ckpt.get("target_gene") != target_gene:
        raise ValueError(
            f"Checkpoint {ckpt_path} is for target_gene={ckpt.get('target_gene')}, expected {target_gene}. "
            "Use --overwrite to restart."
        )
    if ckpt and ckpt.get("cells_sha256") != cells_sha256:
        raise ValueError(f"Checkpoint {ckpt_path} does not match current cell index. Use --overwrite to restart.")
    if ckpt and ckpt.get("genes_sha256") != genes_sha256:
        raise ValueError(f"Checkpoint {ckpt_path} does not match current gene columns. Use --overwrite to restart.")

    ckpt_next = int(ckpt.get("next_cell_idx", 0)) if ckpt else 0
    csv_next = None
    if args.resume and output_path.exists():
        csv_next = _infer_next_cell_idx_from_csv(output_path, df.index)

    if not args.resume:
        start_cell_idx = 0
        if output_path.exists() and not args.overwrite:
            raise ValueError(f"Output already exists: {output_path}. Use --overwrite or --resume.")
    elif output_path.exists():
        if csv_next is None:
            if not ckpt:
                raise ValueError(
                    f"Found existing output {output_path} but could not infer resume point and no checkpoint exists. "
                    "Use --overwrite to restart."
                )
            start_cell_idx = ckpt_next
            print(
                f"[{target_gene}] Warning: could not infer resume point from CSV; using checkpoint next_cell_idx={start_cell_idx}."
            )
        else:
            start_cell_idx = int(csv_next)
            if ckpt and ckpt_next != start_cell_idx:
                print(
                    f"[{target_gene}] Resume mismatch: csv_next={start_cell_idx} vs ckpt_next={ckpt_next}; using csv_next."
                )
    else:
        start_cell_idx = ckpt_next
        if start_cell_idx > 0 and not output_path.exists():
            raise ValueError(
                f"Checkpoint {ckpt_path} indicates progress (next_cell_idx={start_cell_idx}) "
                f"but output CSV is missing: {output_path}. Use --overwrite to restart."
            )

    start_cell_idx = max(0, min(int(start_cell_idx), n_cells))
    if start_cell_idx >= n_cells:
        print(f"[{target_gene}] Output already complete ({n_cells}/{n_cells} cells). Skipping.")
        return

    ckpt_payload = {
        "version": 1,
        "updated_at": _utc_now_iso(),
        "target_gene": target_gene,
        "input_path": str(input_path),
        "output_path": str(output_path),
        "checkpoint_path": str(ckpt_path),
        "shard_idx": int(args.shard_idx),
        "num_shards": int(args.num_shards),
        "batch_size": int(batch_size),
        "top_k": int(top_k),
        "max_new_tokens": int(max_new_tokens),
        "model_name": model_name,
        "n_cells": int(n_cells),
        "n_genes": int(n_genes),
        "cells_sha256": cells_sha256,
        "genes_sha256": genes_sha256,
        "next_cell_idx": int(start_cell_idx),
        "completed": False,
    }
    _atomic_write_json(ckpt_path, ckpt_payload)

    print(f"[{target_gene}] Resuming from cell {start_cell_idx} / {n_cells}")

    run_start_time = time.time()
    run_start_cell_idx = start_cell_idx
    total_batches = (n_cells + batch_size - 1) // batch_size
    run_batches_done = 0

    for start in range(start_cell_idx, n_cells, batch_size):
        end = min(start + batch_size, n_cells)
        batch_sentences = cell_sentences[start:end]
        batch_prompts = [build_prompt(s, target_gene) for s in batch_sentences]

        toks = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True)
        toks = {k: v.to(first_param_device) for k, v in toks.items()}

        with torch.no_grad():
            outputs = model.generate(
                **toks,
                max_new_tokens=max_new_tokens,
                do_sample=False,  # greedy decoding for determinism
                pad_token_id=tokenizer.pad_token_id,
            )
        decoded = tokenizer.batch_decode(outputs, skip_special_tokens=True)

        batch_rows = data[start:end].copy()
        for j, dec in enumerate(decoded):
            prompt = batch_prompts[j]
            cell_idx = start + j
            generated_genes = clean_generated(dec, prompt, target_gene)
            final_genes = complete_gene_list(
                generated_genes, top_genes_per_cell[cell_idx], target_gene
            )

            new_row = batch_rows[j]

            # Reassign expressions based on new ranking
            expr_values = top_expr_per_cell[cell_idx]
            for rank, gene in enumerate(final_genes):
                if rank >= len(expr_values):
                    break
                gi = col_to_idx.get(gene)
                if gi is not None:
                    new_row[gi] = expr_values[rank]

            # Enforce knockout
            if target_idx is not None:
                new_row[target_idx] = 0.0

            batch_rows[j] = new_row

        batch_df = pd.DataFrame(batch_rows, index=df.index[start:end], columns=df.columns)
        write_mode = "w" if start == 0 and start_cell_idx == 0 else "a"
        write_header = write_mode == "w"
        batch_df.to_csv(output_path, mode=write_mode, header=write_header)

        run_batches_done += 1
        if args.checkpoint_every > 0 and (run_batches_done % args.checkpoint_every == 0 or end >= n_cells):
            ckpt_payload["updated_at"] = _utc_now_iso()
            ckpt_payload["next_cell_idx"] = int(end)
            ckpt_payload["completed"] = bool(end >= n_cells)
            ckpt_payload["last_cell_id"] = str(df.index[end - 1])
            _atomic_write_json(ckpt_path, ckpt_payload)

        now_dt = datetime.now().astimezone()
        elapsed_sec = time.time() - run_start_time
        cells_done_this_run = max(0, end - run_start_cell_idx)
        if cells_done_this_run > 0:
            sec_per_cell = elapsed_sec / cells_done_this_run
            remaining_sec = sec_per_cell * (n_cells - end)
            finish_dt = now_dt + timedelta(seconds=remaining_sec)
            eta_str = _format_duration(remaining_sec)
        else:
            eta_str = "unknown"
            finish_dt = None

        batch_idx_global = (end + batch_size - 1) // batch_size
        timestamp_str = now_dt.strftime("%Y-%m-%d %H:%M:%S%z")
        progress_pct = (100.0 * end / n_cells) if n_cells else 100.0
        msg = (
            f"[{target_gene}] {timestamp_str} | "
            f"batch {batch_idx_global}/{total_batches} | "
            f"cells {end}/{n_cells} ({progress_pct:.2f}%) | "
            f"elapsed {_format_duration(elapsed_sec)} | ETA {eta_str}"
        )
        if finish_dt is not None:
            msg += f" | finish {finish_dt.strftime('%Y-%m-%d %H:%M:%S%z')}"
        print(msg, flush=True)

        if run_batches_done % 10 == 0:
            torch.cuda.empty_cache()

    print(f"[{target_gene}] Generation complete.")
    print(f"[{target_gene}] Saved perturbed matrix to:", output_path)

    ckpt_payload["updated_at"] = _utc_now_iso()
    ckpt_payload["next_cell_idx"] = int(n_cells)
    ckpt_payload["completed"] = True
    ckpt_payload["last_cell_id"] = str(df.index[-1])
    _atomic_write_json(ckpt_path, ckpt_payload)

    orig_stats = df[target_gene].describe() if target_gene in df.columns else "not present"
    print(f"[{target_gene}] Original stats:", orig_stats)
    if target_gene in df.columns:
        print(f"[{target_gene}] Perturbed stats: KO enforced -> all zeros.")
    else:
        print(f"[{target_gene}] Perturbed stats: not present.")


for gene in target_genes:
    print(f"=== Running virtual knockout for {gene} ===")
    run_virtual_knockout(gene)
